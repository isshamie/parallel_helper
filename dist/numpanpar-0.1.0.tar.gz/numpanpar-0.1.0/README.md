# numpanpar
A wrapper for multiprocessing that helps pass arguments and operate 
on pandas dataframes and numpy arrays. 


